"""
LoadTest Fabric Environment Package

This package provides all dependencies required for running load tests
against Power BI semantic models in Microsoft Fabric.

Dependencies included:
- polars: High-performance DataFrame library
- deltalake: Delta Lake support for data storage
- ipywidgets: Interactive widgets for notebooks
"""

__version__ = "1.0.0"
__author__ = "Payments Data Platform"

# Re-export commonly used modules for convenience
try:
    import polars as pl
    import deltalake
    import ipywidgets as widgets
except ImportError as e:
    print(f"Warning: Some dependencies not available: {e}")

def get_version():
    """Return package version."""
    return __version__

def check_dependencies():
    """Verify all required dependencies are installed."""
    deps = {
        "polars": False,
        "deltalake": False,
        "ipywidgets": False,
    }
    
    try:
        import polars
        deps["polars"] = polars.__version__
    except ImportError:
        pass
    
    try:
        import deltalake
        deps["deltalake"] = deltalake.__version__
    except ImportError:
        pass
    
    try:
        import ipywidgets
        deps["ipywidgets"] = ipywidgets.__version__
    except ImportError:
        pass
    
    return deps
